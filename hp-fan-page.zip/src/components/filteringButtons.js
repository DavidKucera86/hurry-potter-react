const filteringButtons = ["Studenti", "Učitelé", "Nebelvír", "Zmijozel", "Havraspár", "Mrzimor", "Všichni"]

export default filteringButtons